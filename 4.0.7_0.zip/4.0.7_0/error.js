'use strict';

var EventEmitter = require('./EventEmitter');

module.exports = new EventEmitter();
